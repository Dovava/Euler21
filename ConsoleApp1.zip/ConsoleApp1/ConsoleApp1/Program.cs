﻿List<int> amicables = new List<int>();
int d(int n) {
    int value = 0;
    int loopLength = (int)n / 2;
    for (int i = 1; i <= loopLength; i++)
    {
        if (n % i == 0) {
            value += i;
        }
    }
    return value;
}
for (int i = 2; i < 10001; i++) {
    if (d(d(i)) == i && d(i) > i) {
        amicables.Add(i);
        amicables.Add(d(i));
    }
}
amicables = amicables.Distinct().ToList();
int ans = amicables.Sum();
Console.WriteLine(ans);